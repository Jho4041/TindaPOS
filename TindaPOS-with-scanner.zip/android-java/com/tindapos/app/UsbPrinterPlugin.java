package com.tindapos.app;

import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.usb.UsbConstants;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbDeviceConnection;
import android.hardware.usb.UsbEndpoint;
import android.hardware.usb.UsbInterface;
import android.hardware.usb.UsbManager;
import android.os.Build;
import android.util.Base64;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

@CapacitorPlugin(name = "UsbPrinter")
public class UsbPrinterPlugin extends Plugin {
    private static final String ACTION = "com.tindapos.app.USB_PERMISSION";

    private UsbManager mgr() {
        return (UsbManager) getContext().getSystemService(Context.USB_SERVICE);
    }

    private UsbDevice find(PluginCall call) {
        Integer vid = call.getInt("vendorId");
        Integer pid = call.getInt("productId");
        if (vid == null || pid == null) return null;
        for (UsbDevice d : mgr().getDeviceList().values()) {
            if (d.getVendorId() == vid && d.getProductId() == pid) return d;
        }
        return null;
    }

    private UsbEndpoint bulkOut(UsbDevice d, UsbInterface[] holder) {
        for (int i = 0; i < d.getInterfaceCount(); i++) {
            UsbInterface intf = d.getInterface(i);
            for (int e = 0; e < intf.getEndpointCount(); e++) {
                UsbEndpoint ep = intf.getEndpoint(e);
                if (ep.getType() == UsbConstants.USB_ENDPOINT_XFER_BULK
                        && ep.getDirection() == UsbConstants.USB_DIR_OUT) {
                    holder[0] = intf;
                    return ep;
                }
            }
        }
        return null;
    }

    private boolean isPrinterClass(UsbDevice d) {
        if (d.getDeviceClass() == UsbConstants.USB_CLASS_PRINTER) return true;
        for (int i = 0; i < d.getInterfaceCount(); i++) {
            if (d.getInterface(i).getInterfaceClass() == UsbConstants.USB_CLASS_PRINTER) return true;
        }
        return false;
    }

    @PluginMethod
    public void list(PluginCall call) {
        JSArray arr = new JSArray();
        for (UsbDevice d : mgr().getDeviceList().values()) {
            if (bulkOut(d, new UsbInterface[1]) == null) continue; // must be able to receive data
            JSObject o = new JSObject();
            o.put("vendorId", d.getVendorId());
            o.put("productId", d.getProductId());
            String name = d.getProductName();
            if (name == null || name.isEmpty()) name = String.format("USB device %04X:%04X", d.getVendorId(), d.getProductId());
            o.put("name", name);
            o.put("printer", isPrinterClass(d));
            arr.put(o);
        }
        JSObject r = new JSObject();
        r.put("devices", arr);
        call.resolve(r);
    }

    @PluginMethod
    public void connect(final PluginCall call) {
        final UsbDevice d = find(call);
        if (d == null) { call.reject("USB printer not found. Plug it in."); return; }
        final UsbManager m = mgr();
        if (m.hasPermission(d)) { call.resolve(); return; }

        final Context ctx = getContext();
        BroadcastReceiver rec = new BroadcastReceiver() {
            @Override
            public void onReceive(Context c, Intent intent) {
                try { ctx.unregisterReceiver(this); } catch (Exception ignored) {}
                if (m.hasPermission(d)) call.resolve();
                else call.reject("USB permission was denied.");
            }
        };
        IntentFilter f = new IntentFilter(ACTION);
        if (Build.VERSION.SDK_INT >= 33) ctx.registerReceiver(rec, f, Context.RECEIVER_NOT_EXPORTED);
        else ctx.registerReceiver(rec, f);

        int flags = Build.VERSION.SDK_INT >= 31 ? PendingIntent.FLAG_MUTABLE : 0;
        Intent in = new Intent(ACTION);
        in.setPackage(ctx.getPackageName());
        m.requestPermission(d, PendingIntent.getBroadcast(ctx, 0, in, flags));
    }

    @PluginMethod
    public void print(PluginCall call) {
        UsbDevice d = find(call);
        if (d == null) { call.reject("USB printer not found. Plug it in."); return; }
        UsbManager m = mgr();
        if (!m.hasPermission(d)) { call.reject("No USB permission. Tap Find USB printers and choose it again."); return; }
        String b64 = call.getString("data");
        if (b64 == null) { call.reject("Nothing to print."); return; }
        byte[] data = Base64.decode(b64, Base64.DEFAULT);

        UsbInterface[] holder = new UsbInterface[1];
        UsbEndpoint ep = bulkOut(d, holder);
        if (ep == null) { call.reject("This USB device cannot receive print data."); return; }
        UsbDeviceConnection c = m.openDevice(d);
        if (c == null) { call.reject("Could not open the USB device."); return; }
        try {
            if (!c.claimInterface(holder[0], true)) { call.reject("Could not claim the USB printer interface."); return; }
            int off = 0;
            while (off < data.length) {
                int n = Math.min(4096, data.length - off);
                int w = c.bulkTransfer(ep, data, off, n, 5000);
                if (w < 0) { call.reject("USB write failed."); return; }
                off += w;
            }
            c.releaseInterface(holder[0]);
            call.resolve();
        } finally {
            c.close();
        }
    }
}
