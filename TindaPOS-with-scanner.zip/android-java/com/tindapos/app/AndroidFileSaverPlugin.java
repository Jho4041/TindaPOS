package com.tindapos.app;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.util.Base64;
import com.getcapacitor.ActivityResult;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.JSObject;
import java.io.OutputStream;

@CapacitorPlugin(name = "AndroidFileSaver")
public class AndroidFileSaverPlugin extends Plugin {
    @PluginMethod
    public void saveFile(PluginCall call) {
        String filename = call.getString("filename");
        String data = call.getString("data");
        String mime = call.getString("mime", "application/octet-stream");
        if (filename == null || data == null) {
            call.reject("filename and data are required");
            return;
        }
        try {
            Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType(mime);
            intent.putExtra(Intent.EXTRA_TITLE, filename);
            intent.putExtra("android.content.extra.SHOW_ADVANCED", true);
            saveFileResult(call, intent, data);
        } catch (Exception e) {
            call.reject("Unable to open Android file picker", e);
        }
    }

    private void saveFileResult(PluginCall call, Intent intent, String base64) {
        call.setKeepAlive(true);
        startActivityForResult(call, intent, "handleSaveResult", new JSObject().put("data", base64));
    }

    @ActivityCallback
    private void handleSaveResult(PluginCall call, ActivityResult result, JSObject saved) {
        if (call == null) return;
        if (result.getResultCode() != Activity.RESULT_OK || result.getData() == null) {
            call.reject("File save cancelled");
            return;
        }
        Uri uri = result.getData().getData();
        try {
            byte[] bytes = Base64.decode(saved.getString("data"), Base64.DEFAULT);
            try (OutputStream stream = getContext().getContentResolver().openOutputStream(uri, "wt")) {
                if (stream == null) throw new Exception("Could not open destination");
                stream.write(bytes);
                stream.flush();
            }
            JSObject ret = new JSObject();
            ret.put("uri", uri.toString());
            ret.put("saved", true);
            call.resolve(ret);
        } catch (Exception e) {
            call.reject("Could not write file: " + e.getMessage(), e);
        }
    }
}
