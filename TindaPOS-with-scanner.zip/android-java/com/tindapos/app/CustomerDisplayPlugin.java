package com.tindapos.app;

import android.app.Presentation;
import android.content.Context;
import android.hardware.display.DisplayManager;
import android.os.Bundle;
import android.view.Display;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

/** Shows customer.html on a second screen (HDMI / wireless display) and feeds it the live cart. */
@CapacitorPlugin(name = "CustomerDisplay")
public class CustomerDisplayPlugin extends Plugin {
    private Presentation presentation;
    private WebView web;
    private String pending;

    private Display findDisplay() {
        DisplayManager dm = (DisplayManager) getContext().getSystemService(Context.DISPLAY_SERVICE);
        Display[] ds = dm.getDisplays(DisplayManager.DISPLAY_CATEGORY_PRESENTATION);
        return ds.length > 0 ? ds[0] : null;
    }

    @PluginMethod
    public void displays(PluginCall call) {
        Display d = findDisplay();
        JSObject r = new JSObject();
        r.put("found", d != null);
        r.put("name", d != null ? d.getName() : "");
        r.put("running", presentation != null);
        call.resolve(r);
    }

    @PluginMethod
    public void start(final PluginCall call) {
        final Display d = findDisplay();
        if (d == null) { call.reject("No second screen found. Connect an HDMI or wireless display."); return; }
        getActivity().runOnUiThread(() -> {
            try {
                if (presentation != null) { presentation.dismiss(); presentation = null; }
                presentation = new Presentation(getActivity(), d) {
                    @Override
                    protected void onCreate(Bundle b) {
                        super.onCreate(b);
                        WebView w = new WebView(getContext());
                        w.getSettings().setJavaScriptEnabled(true);
                        w.getSettings().setDomStorageEnabled(true);
                        w.setWebViewClient(new WebViewClient() {
                            @Override
                            public void onPageFinished(WebView v, String url) {
                                if (pending != null) v.evaluateJavascript(pending, null);
                            }
                        });
                        w.loadUrl("file:///android_asset/public/customer.html");
                        setContentView(w);
                        web = w;
                    }
                };
                presentation.setOnDismissListener(dlg -> { presentation = null; web = null; });
                presentation.show();
                call.resolve();
            } catch (Exception e) {
                call.reject("Could not open the second screen: " + e.getMessage());
            }
        });
    }

    @PluginMethod
    public void update(final PluginCall call) {
        String json = call.getString("state");
        if (json == null) { call.resolve(); return; }
        final String js = "window.renderCustomer&&window.renderCustomer(" + json + ");";
        pending = js;
        getActivity().runOnUiThread(() -> {
            if (web != null) web.evaluateJavascript(js, null);
            call.resolve();
        });
    }

    @PluginMethod
    public void stop(final PluginCall call) {
        getActivity().runOnUiThread(() -> {
            if (presentation != null) { presentation.dismiss(); presentation = null; }
            call.resolve();
        });
    }

    @Override
    protected void handleOnDestroy() {
        if (presentation != null) presentation.dismiss();
    }
}
