package com.tindapos.app;

import android.Manifest;
import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.camera.core.Camera;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.ImageProxy;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.LifecycleOwner;

import com.getcapacitor.JSObject;
import com.getcapacitor.PermissionState;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;
import com.google.common.util.concurrent.ListenableFuture;
import com.google.mlkit.vision.barcode.BarcodeScanner;
import com.google.mlkit.vision.barcode.BarcodeScannerOptions;
import com.google.mlkit.vision.barcode.BarcodeScanning;
import com.google.mlkit.vision.barcode.common.Barcode;
import com.google.mlkit.vision.common.InputImage;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * TindaPOS native camera scanner (CameraX + ML Kit), taken from the TindaPOS Scanner app.
 * Shows a full-screen camera overlay on top of the POS WebView and sends every barcode
 * to JavaScript as a "scan" event, so the cart updates without leaving the app.
 *
 * JS API (Capacitor.Plugins.NativeScanner):
 *   start({continuous:true})  -> opens the camera overlay (asks for camera permission first)
 *   stop()                    -> closes it
 *   setStatus({text})         -> shows a line of text at the bottom of the overlay
 *   addListener('scan',    e => e.value, e.format)
 *   addListener('stopped', () => ...)   // user pressed Close / Back
 */
@CapacitorPlugin(
    name = "NativeScanner",
    permissions = { @Permission(alias = "camera", strings = { Manifest.permission.CAMERA }) }
)
public class NativeScannerPlugin extends Plugin {

    private FrameLayout overlay;
    private PreviewView previewView;
    private TextView statusView;
    private Button torchBtn;
    private ProcessCameraProvider provider;
    private Camera camera;
    private BarcodeScanner scanner;
    private ExecutorService executor;
    private final AtomicBoolean busy = new AtomicBoolean(false);
    private volatile boolean active = false;
    private volatile String lastValue = "";
    private volatile long lastAt = 0;
    private boolean torchOn = false;

    @PluginMethod
    public void start(PluginCall call) {
        if (getPermissionState("camera") != PermissionState.GRANTED) {
            requestPermissionForAlias("camera", call, "cameraPermsCallback");
            return;
        }
        openOverlay(call);
    }

    @PermissionCallback
    private void cameraPermsCallback(PluginCall call) {
        if (getPermissionState("camera") == PermissionState.GRANTED) openOverlay(call);
        else call.reject("Camera permission denied. Allow Camera for TindaPOS in Android settings.");
    }

    @PluginMethod
    public void stop(PluginCall call) {
        getActivity().runOnUiThread(() -> { closeOverlay(false); call.resolve(); });
    }

    @PluginMethod
    public void setStatus(PluginCall call) {
        final String text = call.getString("text", "");
        getActivity().runOnUiThread(() -> { if (statusView != null) statusView.setText(text); });
        call.resolve();
    }

    private int dp(int v) {
        return Math.round(v * getActivity().getResources().getDisplayMetrics().density);
    }

    private void openOverlay(final PluginCall call) {
        final Activity act = getActivity();
        act.runOnUiThread(() -> {
            if (overlay != null) { call.resolve(); return; }
            try {
                scanner = BarcodeScanning.getClient(new BarcodeScannerOptions.Builder()
                    .setBarcodeFormats(Barcode.FORMAT_EAN_13, Barcode.FORMAT_EAN_8,
                        Barcode.FORMAT_UPC_A, Barcode.FORMAT_UPC_E,
                        Barcode.FORMAT_CODE_128, Barcode.FORMAT_CODE_39, Barcode.FORMAT_QR_CODE)
                    .build());
                executor = Executors.newSingleThreadExecutor();

                FrameLayout root = new FrameLayout(act);
                root.setBackgroundColor(Color.BLACK);
                root.setClickable(true);
                root.setFitsSystemWindows(true);

                previewView = new PreviewView(act);
                root.addView(previewView, new FrameLayout.LayoutParams(-1, -1));

                // aiming line
                View line = new View(act);
                line.setBackgroundColor(Color.argb(190, 255, 60, 60));
                FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-1, dp(2), Gravity.CENTER);
                lp.setMargins(dp(40), 0, dp(40), 0);
                root.addView(line, lp);

                // top bar
                LinearLayout bar = new LinearLayout(act);
                bar.setOrientation(LinearLayout.HORIZONTAL);
                bar.setGravity(Gravity.CENTER_VERTICAL);
                bar.setBackgroundColor(Color.argb(150, 0, 0, 0));
                bar.setPadding(dp(14), dp(8), dp(10), dp(8));
                TextView title = new TextView(act);
                title.setText("Scan barcode");
                title.setTextColor(Color.WHITE);
                title.setTextSize(18);
                title.setTypeface(null, Typeface.BOLD);
                bar.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));
                torchBtn = new Button(act);
                torchBtn.setText("Light");
                torchBtn.setOnClickListener(v -> toggleTorch());
                bar.addView(torchBtn, new LinearLayout.LayoutParams(-2, -2));
                Button close = new Button(act);
                close.setText("Close");
                close.setOnClickListener(v -> closeOverlay(true));
                bar.addView(close, new LinearLayout.LayoutParams(-2, -2));
                root.addView(bar, new FrameLayout.LayoutParams(-1, -2, Gravity.TOP));

                // bottom status
                statusView = new TextView(act);
                statusView.setText("Point at a barcode. Items are added automatically.");
                statusView.setTextColor(Color.WHITE);
                statusView.setTextSize(16);
                statusView.setGravity(Gravity.CENTER);
                statusView.setBackgroundColor(Color.argb(150, 0, 0, 0));
                statusView.setPadding(dp(14), dp(12), dp(14), dp(12));
                root.addView(statusView, new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM));

                // hardware Back closes the scanner instead of the app
                root.setFocusableInTouchMode(true);
                root.setOnKeyListener((v, keyCode, event) -> {
                    if (keyCode == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_UP) {
                        closeOverlay(true);
                        return true;
                    }
                    return keyCode == KeyEvent.KEYCODE_BACK;
                });

                overlay = root;
                act.addContentView(root, new ViewGroup.LayoutParams(-1, -1));
                root.requestFocus();

                active = true;
                lastValue = "";
                lastAt = 0;
                torchOn = false;
                startCamera(act, call);
            } catch (Exception e) {
                closeOverlay(false);
                call.reject("Could not open scanner: " + e.getMessage());
            }
        });
    }

    private void startCamera(final Activity act, final PluginCall call) {
        final ListenableFuture<ProcessCameraProvider> future = ProcessCameraProvider.getInstance(act);
        future.addListener(() -> {
            try {
                provider = future.get();
                Preview preview = new Preview.Builder().build();
                preview.setSurfaceProvider(previewView.getSurfaceProvider());
                ImageAnalysis analysis = new ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build();
                analysis.setAnalyzer(executor, this::analyze);
                provider.unbindAll();
                camera = provider.bindToLifecycle((LifecycleOwner) act,
                    CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis);
                call.resolve();
            } catch (Exception e) {
                closeOverlay(false);
                call.reject("Camera error: " + e.getMessage());
            }
        }, ContextCompat.getMainExecutor(act));
    }

    private void analyze(ImageProxy proxy) {
        if (!active || scanner == null || !busy.compareAndSet(false, true)) { proxy.close(); return; }
        @SuppressWarnings("UnsafeOptInUsageError")
        android.media.Image media = proxy.getImage();
        if (media == null) { busy.set(false); proxy.close(); return; }
        try {
            InputImage input = InputImage.fromMediaImage(media, proxy.getImageInfo().getRotationDegrees());
            scanner.process(input)
                .addOnSuccessListener(list -> {
                    long now = System.currentTimeMillis();
                    for (Barcode b : list) {
                        final String v = b.getRawValue();
                        if (v == null || v.trim().isEmpty()) continue;
                        // ignore the same barcode while it stays in view
                        if (v.equals(lastValue) && now - lastAt < 1800) break;
                        lastValue = v;
                        lastAt = now;
                        final JSObject o = new JSObject();
                        o.put("value", v.trim());
                        o.put("format", b.getFormat());
                        final Activity act = getActivity();
                        if (act != null) act.runOnUiThread(() -> {
                            if (statusView != null) statusView.setText("Scanned: " + v.trim());
                            notifyListeners("scan", o);
                        });
                        break;
                    }
                })
                .addOnCompleteListener(t -> { busy.set(false); proxy.close(); });
        } catch (Exception e) {
            busy.set(false);
            proxy.close();
        }
    }

    private void toggleTorch() {
        try {
            if (camera != null && camera.getCameraInfo().hasFlashUnit()) {
                torchOn = !torchOn;
                camera.getCameraControl().enableTorch(torchOn);
                torchBtn.setText(torchOn ? "Light on" : "Light");
            } else if (statusView != null) {
                statusView.setText("This device has no camera light.");
            }
        } catch (Exception ignored) {
        }
    }

    /** Must run on the UI thread. */
    private void closeOverlay(boolean notifyJs) {
        boolean wasOpen = overlay != null;
        active = false;
        try { if (provider != null) provider.unbindAll(); } catch (Exception ignored) {}
        try { if (scanner != null) scanner.close(); } catch (Exception ignored) {}
        try { if (executor != null) executor.shutdown(); } catch (Exception ignored) {}
        if (overlay != null && overlay.getParent() instanceof ViewGroup) {
            ((ViewGroup) overlay.getParent()).removeView(overlay);
        }
        overlay = null;
        previewView = null;
        statusView = null;
        torchBtn = null;
        camera = null;
        scanner = null;
        executor = null;
        torchOn = false;
        busy.set(false);
        if (wasOpen && notifyJs) notifyListeners("stopped", new JSObject());
    }

    @Override
    protected void handleOnDestroy() {
        final Activity act = getActivity();
        if (act != null) act.runOnUiThread(() -> closeOverlay(false));
    }
}
