package com.tindapos.app;

import android.Manifest;
import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothClass;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.Base64;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.PermissionState;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.UUID;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

@SuppressLint("MissingPermission")
@CapacitorPlugin(
    name = "BtDevices",
    permissions = {
        @Permission(alias = "btnew", strings = { Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_ADVERTISE }),
        @Permission(alias = "btold", strings = { Manifest.permission.ACCESS_FINE_LOCATION })
    }
)
public class BtDevicesPlugin extends Plugin {
    private static final UUID SPP = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private BroadcastReceiver scanReceiver;
    private volatile boolean discovering = false;

    // Printer and scanner use two separate Bluetooth connections that never share state.
    private final Object connectLock = new Object();          // Android connects best one device at a time
    private final ExecutorService printExec = Executors.newSingleThreadExecutor();
    private final AtomicInteger printBusy = new AtomicInteger(0); // the scanner waits while a print is pending
    private volatile BluetoothSocket printSocket;
    private volatile String printAddr;
    private volatile long printLastUse = 0;
    private final Handler idleHandler = new Handler(Looper.getMainLooper());
    private final Runnable idleClose = () -> printExec.execute(() -> {
        if (printBusy.get() == 0 && SystemClock.elapsedRealtime() - printLastUse >= 90000) closePrinter();
    });
    private final AtomicInteger readGen = new AtomicInteger(0);   // which scanner session is current
    private volatile BluetoothSocket readSocket;
    private volatile boolean scannerLinked = false;

    // "Phone as scanner": this phone waits for the main device and sends each scanned code to it
    private volatile BluetoothServerSocket serverSocket;
    private volatile BluetoothSocket serverClient;
    private final AtomicInteger serverGen = new AtomicInteger(0);
    private final ConcurrentLinkedQueue<String> outbox = new ConcurrentLinkedQueue<>();
    private final Object sendLock = new Object();

    private static void sleepQuiet(long ms) { try { Thread.sleep(ms); } catch (InterruptedException ignored) {} }

    // ---------- helpers ----------
    private BluetoothAdapter adapter() {
        BluetoothManager m = (BluetoothManager) getContext().getSystemService(Context.BLUETOOTH_SERVICE);
        return m == null ? null : m.getAdapter();
    }

    private String alias() { return Build.VERSION.SDK_INT >= 31 ? "btnew" : "btold"; }

    private boolean granted() { return getPermissionState(alias()) == PermissionState.GRANTED; }

    private void withPermission(PluginCall call) {
        if (granted()) dispatch(call);
        else requestPermissionForAlias(alias(), call, "permResult");
    }

    @PermissionCallback
    private void permResult(PluginCall call) {
        if (granted()) dispatch(call);
        else call.reject("Bluetooth permission was denied. Allow it in Android settings.");
    }

    private void dispatch(PluginCall call) {
        BluetoothAdapter a = adapter();
        if (a == null) { call.reject("This device has no Bluetooth."); return; }
        if (!a.isEnabled()) { call.reject("Turn Bluetooth on first."); return; }
        switch (call.getMethodName()) {
            case "paired": doPaired(call, a); break;
            case "startScan": doStartScan(call, a); break;
            case "pair": doPair(call, a); break;
            case "print": doPrint(call, a); break;
            case "connectPrinter": doConnectPrinter(call, a); break;
            case "unpair": doUnpair(call, a); break;
            case "startReading": doStartReading(call, a); break;
            case "startServer": doStartServer(call, a); break;
            case "makeDiscoverable": doMakeDiscoverable(call); break;
            default: call.reject("Unknown action.");
        }
    }

    private String kind(BluetoothDevice d) {
        BluetoothClass bc = d.getBluetoothClass();
        int major = bc == null ? -1 : bc.getMajorDeviceClass();
        String n = d.getName() == null ? "" : d.getName().toLowerCase();
        if (major == BluetoothClass.Device.Major.IMAGING
                || n.matches(".*(printer|pos|rpp|mpt|mtp|pt-|xprinter|goojprt|hprt|sunmi|bt-?\\d|thermal).*")) return "printer";
        if (major == BluetoothClass.Device.Major.PERIPHERAL
                || n.matches(".*(scan|barcode|eyoyo|netum|inateck|symcode|tera|zebra|honeywell).*")) return "scanner";
        return "other";
    }

    private JSObject json(BluetoothDevice d) {
        JSObject o = new JSObject();
        String n = d.getName();
        o.put("name", n == null || n.isEmpty() ? d.getAddress() : n);
        o.put("address", d.getAddress());
        o.put("bonded", d.getBondState() == BluetoothDevice.BOND_BONDED);
        o.put("kind", kind(d));
        return o;
    }

    // ---------- plugin methods ----------
    @PluginMethod public void paired(PluginCall call) { withPermission(call); }
    @PluginMethod public void startScan(PluginCall call) { withPermission(call); }
    @PluginMethod public void pair(PluginCall call) { withPermission(call); }
    @PluginMethod public void print(PluginCall call) { withPermission(call); }
    @PluginMethod public void connectPrinter(PluginCall call) { withPermission(call); }
    @PluginMethod public void unpair(PluginCall call) { withPermission(call); }
    @PluginMethod public void startServer(PluginCall call) { withPermission(call); }
    @PluginMethod public void makeDiscoverable(PluginCall call) { withPermission(call); }

    @PluginMethod
    public void stopServer(PluginCall call) {
        serverGen.incrementAndGet();
        closeServer();
        outbox.clear();
        call.resolve();
    }

    @PluginMethod
    public void send(PluginCall call) {
        String code = call.getString("code");
        if (code == null || code.isEmpty()) { call.reject("No code."); return; }
        JSObject r = new JSObject();
        synchronized (sendLock) {
            BluetoothSocket c = serverClient;
            if (c != null) {
                try {
                    OutputStream o = c.getOutputStream();
                    o.write((code + "\n").getBytes("UTF-8"));
                    o.flush();
                    r.put("sent", true);
                    call.resolve(r);
                    return;
                } catch (IOException e) { /* connection dropped: keep the code and send it after reconnecting */ }
            }
            while (outbox.size() >= 50) outbox.poll();
            outbox.add(code);
            r.put("sent", false);
            r.put("queued", outbox.size());
        }
        call.resolve(r);
    }

    @PluginMethod
    public void openSettings(PluginCall call) {
        Intent i = new Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        getContext().startActivity(i);
        call.resolve();
    }
    @PluginMethod public void startReading(PluginCall call) { withPermission(call); }

    @PluginMethod
    public void stopScan(PluginCall call) {
        stopDiscovery();
        call.resolve();
    }

    @PluginMethod
    public void stopReading(PluginCall call) {
        stopReadingInternal();
        call.resolve();
    }

    @PluginMethod
    public void status(PluginCall call) {
        BluetoothSocket ps = printSocket;
        JSObject r = new JSObject();
        r.put("printer", ps != null && ps.isConnected());
        r.put("scanner", scannerLinked);
        call.resolve(r);
    }

    // ---------- implementations ----------
    private void doPaired(PluginCall call, BluetoothAdapter a) {
        JSArray arr = new JSArray();
        for (BluetoothDevice d : a.getBondedDevices()) arr.put(json(d));
        JSObject r = new JSObject();
        r.put("devices", arr);
        call.resolve(r);
    }

    private void doStartScan(PluginCall call, BluetoothAdapter a) {
        stopDiscovery();
        discovering = true;
        scanReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context c, Intent intent) {
                String act = intent.getAction();
                if (BluetoothDevice.ACTION_FOUND.equals(act)) {
                    BluetoothDevice d = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                    if (d != null) notifyListeners("deviceFound", json(d));
                } else if (BluetoothAdapter.ACTION_DISCOVERY_FINISHED.equals(act)) {
                    stopDiscovery();
                    notifyListeners("scanFinished", new JSObject());
                }
            }
        };
        IntentFilter f = new IntentFilter();
        f.addAction(BluetoothDevice.ACTION_FOUND);
        f.addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED);
        if (Build.VERSION.SDK_INT >= 33) getContext().registerReceiver(scanReceiver, f, Context.RECEIVER_EXPORTED);
        else getContext().registerReceiver(scanReceiver, f);
        if (!a.startDiscovery()) {
            stopDiscovery();
            call.reject("Could not start scanning. On older Android versions, turn Location on.");
            return;
        }
        call.resolve();
    }

    private void doUnpair(PluginCall call, BluetoothAdapter a) {
        String addr = call.getString("address");
        if (addr == null) { call.reject("No device."); return; }
        if (addr.equals(printAddr)) closePrinter();
        BluetoothDevice d = a.getRemoteDevice(addr);
        if (d.getBondState() != BluetoothDevice.BOND_BONDED) { call.resolve(); return; }
        try {
            Object ok = d.getClass().getMethod("removeBond").invoke(d);
            if (Boolean.TRUE.equals(ok)) call.resolve();
            else call.reject("Android would not remove it.");
        } catch (Exception e) {
            call.reject("Android would not remove it.");
        }
    }

    private void doPair(PluginCall call, BluetoothAdapter a) {
        String addr = call.getString("address");
        if (addr == null) { call.reject("No device."); return; }
        BluetoothDevice d = a.getRemoteDevice(addr);
        if (d.getBondState() == BluetoothDevice.BOND_BONDED) { call.resolve(); return; }
        if (!d.createBond()) { call.reject("Could not start pairing."); return; }
        call.resolve();
    }

    // One connection attempt at a time, so the printer and the scanner never fight over the radio.
    private BluetoothSocket connect(BluetoothAdapter a, BluetoothDevice d) throws IOException {
        synchronized (connectLock) {
            try { a.cancelDiscovery(); } catch (Exception ignored) {}
            BluetoothSocket s = null;
            try {
                s = d.createRfcommSocketToServiceRecord(SPP);
                s.connect();
                sleepQuiet(250);
                return s;
            } catch (IOException first) {
                if (s != null) try { s.close(); } catch (IOException ignored) {}
                BluetoothSocket s2 = null;
                try {
                    s2 = (BluetoothSocket) d.getClass().getMethod("createRfcommSocket", int.class).invoke(d, 1);
                    s2.connect();
                    sleepQuiet(250);
                    return s2;
                } catch (Exception second) {
                    if (s2 != null) try { s2.close(); } catch (IOException ignored) {}
                    throw new IOException("Could not connect. Is the device on, paired and in range?");
                }
            }
        }
    }

    // ---------- printer: one kept-open connection, reused for every receipt ----------
    private BluetoothSocket ensurePrinter(BluetoothAdapter a, String addr) throws IOException {
        BluetoothSocket s = printSocket;
        if (s != null && addr.equals(printAddr) && s.isConnected()) return s;
        closePrinter();
        s = connect(a, a.getRemoteDevice(addr));
        printSocket = s;
        printAddr = addr;
        return s;
    }

    private void closePrinter() {
        BluetoothSocket s = printSocket;
        printSocket = null;
        printAddr = null;
        if (s != null) try { s.close(); } catch (IOException ignored) {}
    }

    private void touchPrinter() {
        printLastUse = SystemClock.elapsedRealtime();
        idleHandler.removeCallbacks(idleClose);
        idleHandler.postDelayed(idleClose, 95000);
    }

    private void doConnectPrinter(final PluginCall call, final BluetoothAdapter a) {
        final String addr = call.getString("address");
        if (addr == null) { call.reject("No printer."); return; }
        printBusy.incrementAndGet();
        printExec.execute(() -> {
            try { ensurePrinter(a, addr); touchPrinter(); call.resolve(); }
            catch (IOException e) { call.reject(e.getMessage()); }
            finally { printBusy.decrementAndGet(); }
        });
    }

    private void doPrint(final PluginCall call, final BluetoothAdapter a) {
        final String addr = call.getString("address"), b64 = call.getString("data");
        if (addr == null || b64 == null) { call.reject("Nothing to print."); return; }
        final byte[] data = Base64.decode(b64, Base64.DEFAULT);
        printBusy.incrementAndGet();
        printExec.execute(() -> {
            try { writePrinter(a, addr, data); call.resolve(); }
            catch (IOException e) { call.reject(e.getMessage()); }
            finally { printBusy.decrementAndGet(); }
        });
    }

    private void writePrinter(BluetoothAdapter a, String addr, byte[] data) throws IOException {
        IOException last = null;
        for (int attempt = 0; attempt < 2; attempt++) { // second try reconnects if the printer dropped while idle
            try {
                BluetoothSocket s = ensurePrinter(a, addr);
                OutputStream o = s.getOutputStream();
                for (int off = 0; off < data.length; off += 512) {
                    o.write(data, off, Math.min(512, data.length - off));
                    o.flush();
                }
                sleepQuiet(200);
                touchPrinter();
                return;
            } catch (IOException e) {
                last = e;
                closePrinter();
            }
        }
        throw last != null ? last : new IOException("Print failed.");
    }

    // ---------- scanner: own connection that reconnects by itself ----------
    private void doStartReading(final PluginCall call, final BluetoothAdapter a) {
        final String addr = call.getString("address");
        if (addr == null) { call.reject("No device."); return; }
        final int gen = readGen.incrementAndGet();
        closeReadSocket();
        call.resolve();
        new Thread(() -> {
            while (readGen.get() == gen) {
                // let a pending print or a manual device scan go first
                while ((printBusy.get() > 0 || discovering) && readGen.get() == gen) sleepQuiet(300);
                if (readGen.get() != gen) break;
                BluetoothSocket s = null;
                try {
                    s = connect(a, a.getRemoteDevice(addr));
                    if (readGen.get() != gen) break;
                    readSocket = s;
                    scannerLinked = true;
                    notifyListeners("readingStarted", new JSObject());
                    InputStream in = s.getInputStream();
                    StringBuilder sb = new StringBuilder();
                    int ch;
                    while (readGen.get() == gen && (ch = in.read()) != -1) {
                        if (ch == '\n' || ch == '\r') {
                            if (sb.length() > 0) {
                                JSObject o = new JSObject();
                                o.put("code", sb.toString());
                                notifyListeners("scan", o);
                                sb.setLength(0);
                            }
                        } else sb.append((char) ch);
                    }
                } catch (IOException ignored) {
                } finally {
                    if (readSocket == s) { readSocket = null; scannerLinked = false; }
                    if (s != null) try { s.close(); } catch (IOException ignored) {}
                }
                if (readGen.get() == gen) {
                    notifyListeners("readingStopped", new JSObject());
                    sleepQuiet(4000); // then try to reconnect
                }
            }
        }, "bt-scanner").start();
    }

    private void closeReadSocket() {
        BluetoothSocket s = readSocket;
        readSocket = null;
        scannerLinked = false;
        if (s != null) try { s.close(); } catch (IOException ignored) {}
    }

    private void doMakeDiscoverable(PluginCall call) {
        try {
            Intent i = new Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE);
            i.putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 120);
            getActivity().startActivity(i);
            call.resolve();
        } catch (Exception e) {
            call.reject("Could not make this phone visible. Open Android Bluetooth settings instead.");
        }
    }

    private void closeServer() {
        BluetoothServerSocket ss = serverSocket;
        BluetoothSocket c = serverClient;
        serverSocket = null;
        serverClient = null;
        if (c != null) try { c.close(); } catch (IOException ignored) {}
        if (ss != null) try { ss.close(); } catch (IOException ignored) {}
    }

    private void doStartServer(final PluginCall call, final BluetoothAdapter a) {
        final int gen = serverGen.incrementAndGet();
        closeServer();
        final BluetoothServerSocket ss;
        try {
            ss = a.listenUsingRfcommWithServiceRecord("TindaPOS Scanner", SPP);
        } catch (IOException e) {
            call.reject("Could not start scanner mode: " + e.getMessage());
            return;
        }
        serverSocket = ss;
        call.resolve();
        new Thread(() -> {
            while (serverGen.get() == gen) {
                BluetoothSocket c;
                try {
                    c = ss.accept(); // waits until the main device connects
                } catch (IOException e) {
                    break;
                }
                if (serverGen.get() != gen) { try { c.close(); } catch (IOException ignored) {} break; }
                synchronized (sendLock) {
                    serverClient = c;
                    try {
                        OutputStream o = c.getOutputStream();
                        String q;
                        while ((q = outbox.poll()) != null) { o.write((q + "\n").getBytes("UTF-8")); }
                        o.flush();
                    } catch (IOException ignored) {}
                }
                JSObject on = new JSObject();
                on.put("connected", true);
                String nm = c.getRemoteDevice().getName();
                on.put("name", nm == null ? c.getRemoteDevice().getAddress() : nm);
                notifyListeners("serverClient", on);
                try {
                    InputStream in = c.getInputStream();
                    while (serverGen.get() == gen && in.read() != -1) { /* the main device sends nothing; this just detects a disconnect */ }
                } catch (IOException ignored) {
                } finally {
                    synchronized (sendLock) { if (serverClient == c) serverClient = null; }
                    try { c.close(); } catch (IOException ignored) {}
                }
                if (serverGen.get() == gen) {
                    JSObject off = new JSObject();
                    off.put("connected", false);
                    notifyListeners("serverClient", off);
                }
            }
            if (serverGen.get() == gen) notifyListeners("serverStopped", new JSObject());
        }, "bt-scanner-server").start();
    }

    private void stopReadingInternal() {
        readGen.incrementAndGet();
        closeReadSocket();
    }

    private void stopDiscovery() {
        discovering = false;
        BluetoothAdapter a = adapter();
        if (a != null) try { a.cancelDiscovery(); } catch (Exception ignored) {}
        if (scanReceiver != null) {
            try { getContext().unregisterReceiver(scanReceiver); } catch (Exception ignored) {}
            scanReceiver = null;
        }
    }

    @Override
    protected void handleOnDestroy() {
        stopDiscovery();
        stopReadingInternal();
        serverGen.incrementAndGet();
        closeServer();
        closePrinter();
        printExec.shutdown();
    }
}
