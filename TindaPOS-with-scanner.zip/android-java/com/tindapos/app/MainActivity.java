package com.tindapos.app;

import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(UsbPrinterPlugin.class);
        registerPlugin(BtDevicesPlugin.class);
        registerPlugin(CustomerDisplayPlugin.class);
        registerPlugin(AndroidFileSaverPlugin.class);
        registerPlugin(NativeScannerPlugin.class);
        super.onCreate(savedInstanceState);
    }
}
