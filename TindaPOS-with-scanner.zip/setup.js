// One-step setup: node setup.js
// Creates the Android Studio project (android/), adds the TindaPOS USB/Bluetooth code and permissions.
const fs = require('fs'), path = require('path'), { execSync } = require('child_process');
const run = c => { console.log('\n> ' + c); execSync(c, { stdio: 'inherit' }); };

if (!fs.existsSync('node_modules') || !fs.existsSync(path.join('node_modules', '@capacitor', 'filesystem'))) run('npm install');
if (!fs.existsSync('android')) run('npx cap add android');

// 1) native plugins
const javaDir = path.join('android', 'app', 'src', 'main', 'java', 'com', 'tindapos', 'app');
fs.mkdirSync(javaDir, { recursive: true });
for (const f of fs.readdirSync(path.join('android-java', 'com', 'tindapos', 'app')))
  fs.copyFileSync(path.join('android-java', 'com', 'tindapos', 'app', f), path.join(javaDir, f));
console.log('Copied native plugins to', javaDir);

// 2) manifest permissions (safe to run again)
const mf = path.join('android', 'app', 'src', 'main', 'AndroidManifest.xml');
let m = fs.readFileSync(mf, 'utf8');
const add = [];
if (!m.includes('android.permission.CAMERA')) add.push('<uses-permission android:name="android.permission.CAMERA" />');
if (!m.includes('android.hardware.usb.host')) add.push('<uses-feature android:name="android.hardware.usb.host" android:required="false" />');
if (!m.includes('BLUETOOTH_CONNECT')) add.push(fs.readFileSync(path.join('android-extra', 'bt-permissions.xml'), 'utf8').trim());
if (!m.includes('BLUETOOTH_ADVERTISE') && !add.some(x => x.includes('BLUETOOTH_ADVERTISE'))) add.push('<uses-permission android:name="android.permission.BLUETOOTH_ADVERTISE" />');
if (add.length) {
  const marker = /<uses-permission android:name="android.permission.INTERNET"\s*\/>/;
  if (!marker.test(m)) { console.error('Could not find the INTERNET permission line in AndroidManifest.xml'); process.exit(1); }
  m = m.replace(marker, mm => mm + '\n    ' + add.join('\n    '));
  fs.writeFileSync(mf, m);
  console.log('Added permissions to AndroidManifest.xml');
}

// 2b) camera scanner libraries (CameraX + ML Kit) in app/build.gradle
const gf = path.join('android', 'app', 'build.gradle');
let g = fs.readFileSync(gf, 'utf8');
const deps = ['androidx.camera:camera-camera2:1.3.4', 'androidx.camera:camera-lifecycle:1.3.4', 'androidx.camera:camera-view:1.3.4', 'com.google.mlkit:barcode-scanning:17.3.0']
  .filter(d => !g.includes(d.split(':')[1]));
if (deps.length) {
  const mm = /^dependencies\s*\{[ \t]*\r?\n/m.exec(g);
  if (!mm) { console.error('Could not find the dependencies block in android/app/build.gradle'); process.exit(1); }
  g = g.slice(0, mm.index + mm[0].length) + deps.map(d => "    implementation '" + d + "'\n").join('') + g.slice(mm.index + mm[0].length);
  fs.writeFileSync(gf, g);
  console.log('Added camera scanner libraries to build.gradle');
}

// 3) copy the web app into Android
run('npx cap sync android');
console.log('\nDone. Open the "android" folder in Android Studio, then: Build > Build APK(s).');
