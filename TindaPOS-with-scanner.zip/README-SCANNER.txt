TindaPOS with built-in camera scanner
- Sell tab > "Scan with camera" now uses a native camera scanner (CameraX + ML Kit) and adds every barcode to the cart.
- New file: android-java/com/tindapos/app/NativeScannerPlugin.java (registered in MainActivity.java).
- setup.js now also adds the camera/ML Kit libraries to android/app/build.gradle.
Build: upload this whole folder (with the hidden .github folder) to GitHub > Actions > "Build TindaPOS APK" > Run workflow
> download artifact TindaPOS-debug-apk. Or locally: node setup.js, then open android/ in Android Studio.
Not compiled or device-tested here.
