#!/usr/bin/env python3
"""
Adds the TindaPOS native camera scanner to a Capacitor Android project.

Usage (from the project root, the folder that contains android/ and www/):
    python3 native-scanner/apply_scanner.py            # or: python3 apply_scanner.py /path/to/project

What it does (safe to run more than once):
  1. copies NativeScannerPlugin.java next to MainActivity (package name matched automatically)
  2. registers the plugin in MainActivity (Java or Kotlin)
  3. adds the CameraX + ML Kit dependencies to android/app/build.gradle(.kts)
  4. makes sure the CAMERA permission is in AndroidManifest.xml
"""
import os
import re
import sys
import glob

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(sys.argv[1]) if len(sys.argv) > 1 else os.getcwd()
ANDROID = os.path.join(ROOT, "android")

DEPS = [
    "androidx.camera:camera-camera2:1.3.4",
    "androidx.camera:camera-lifecycle:1.3.4",
    "androidx.camera:camera-view:1.3.4",
    "com.google.mlkit:barcode-scanning:17.3.0",
]


def read(p):
    with open(p, encoding="utf-8") as f:
        return f.read()


def write(p, s):
    with open(p, "w", encoding="utf-8", newline="\n") as f:
        f.write(s)


def fail(msg):
    print("ERROR: " + msg)
    sys.exit(1)


if not os.path.isdir(ANDROID):
    fail("No android/ folder in %s. Run `npx cap add android` (or `npx cap sync android`) first, "
         "or pass the project folder: python3 apply_scanner.py /path/to/project" % ROOT)

# ---- 1 + 2: MainActivity + plugin ------------------------------------------------------------
cands = glob.glob(os.path.join(ANDROID, "app", "src", "main", "java", "**", "MainActivity.*"), recursive=True)
cands = [c for c in cands if c.endswith((".java", ".kt"))]
if not cands:
    fail("MainActivity.java / MainActivity.kt not found under android/app/src/main/java")
main = cands[0]
src = read(main)
m = re.search(r"^\s*package\s+([\w.]+)", src, re.M)
if not m:
    fail("Could not read the package name from " + main)
pkg = m.group(1)
is_kt = main.endswith(".kt")

plugin_dst = os.path.join(os.path.dirname(main), "NativeScannerPlugin.java")
plugin_src = read(os.path.join(HERE, "NativeScannerPlugin.java")).replace("__PACKAGE__", pkg)
write(plugin_dst, plugin_src)
print("OK  plugin copied   -> " + os.path.relpath(plugin_dst, ROOT))

if "NativeScannerPlugin" in src:
    print("OK  MainActivity already registers the plugin")
else:
    reg = "registerPlugin(NativeScannerPlugin::class.java)" if is_kt else "registerPlugin(NativeScannerPlugin.class);"
    if re.search(r"super\.onCreate\(", src):
        src = re.sub(r"^([ \t]*)super\.onCreate\(", lambda mm: mm.group(1) + reg + "\n" + mm.group(1) + "super.onCreate(",
                     src, count=1, flags=re.M)
    else:
        # stock empty MainActivity: add an onCreate override
        if is_kt:
            body = ("    override fun onCreate(savedInstanceState: Bundle?) {\n"
                    "        " + reg + "\n"
                    "        super.onCreate(savedInstanceState)\n"
                    "    }\n")
            if "import android.os.Bundle" not in src:
                src = re.sub(r"(^package .*$)", r"\1\n\nimport android.os.Bundle", src, count=1, flags=re.M)
        else:
            body = ("    @Override\n"
                    "    public void onCreate(android.os.Bundle savedInstanceState) {\n"
                    "        " + reg + "\n"
                    "        super.onCreate(savedInstanceState);\n"
                    "    }\n")
        if re.search(r"\{\s*\}\s*$", src.strip()):
            src = re.sub(r"\{\s*\}\s*$", "{\n" + body + "}\n", src.rstrip(), count=1)
        else:
            idx = src.rstrip().rfind("}")
            src = src[:idx] + body + "}\n"
    write(main, src)
    print("OK  plugin registered in " + os.path.relpath(main, ROOT))

# ---- 3: gradle dependencies ------------------------------------------------------------------
gradle = None
for name in ("build.gradle", "build.gradle.kts"):
    p = os.path.join(ANDROID, "app", name)
    if os.path.exists(p):
        gradle = p
        break
if not gradle:
    print("WARN android/app/build.gradle not found. Add these to its dependencies block yourself:")
    for d in DEPS:
        print("       implementation '%s'" % d)
else:
    g = read(gradle)
    kts = gradle.endswith(".kts")
    missing = [d for d in DEPS if d.split(":")[1] not in g]
    if not missing:
        print("OK  gradle dependencies already present")
    else:
        lines = "".join("    implementation(\"%s\")\n" % d if kts else "    implementation '%s'\n" % d for d in missing)
        mm = re.search(r"^dependencies\s*\{[ \t]*\n", g, re.M)
        if not mm:
            print("WARN could not find a `dependencies {` block in %s. Add:\n%s" % (gradle, lines))
        else:
            g = g[:mm.end()] + lines + g[mm.end():]
            write(gradle, g)
            print("OK  gradle dependencies added -> " + os.path.relpath(gradle, ROOT))

# ---- 4: manifest -----------------------------------------------------------------------------
mf = os.path.join(ANDROID, "app", "src", "main", "AndroidManifest.xml")
if os.path.exists(mf):
    x = read(mf)
    add = ""
    if "android.permission.CAMERA" not in x:
        add += '    <uses-permission android:name="android.permission.CAMERA" />\n'
    if "android.hardware.camera" not in x:
        add += '    <uses-feature android:name="android.hardware.camera" android:required="false" />\n'
    if add:
        x = x.replace("</manifest>", add + "</manifest>", 1)
        write(mf, x)
        print("OK  manifest updated (camera permission)")
    else:
        print("OK  manifest already has camera permission")
else:
    print("WARN AndroidManifest.xml not found; make sure it has android.permission.CAMERA")

print("\nDone. Now sync and build:  npx cap sync android   then build the APK as usual.")
