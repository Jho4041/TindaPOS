TindaPOS + built-in camera scanner
==================================

What changed
- The camera scanner from "TindaPOS Scanner" (CameraX + ML Kit) is now a native plugin inside TindaPOS.
- Sell tab -> "Scan with camera" opens a full-screen camera. Every barcode is added to the cart
  automatically (same handleScan() as USB / Bluetooth scanners). Camera stays open for the next item.
  It closes by itself when a popup is needed (new barcode, weight or volume item). Close / Back button closes it.
- No second app, no Windows helper, no pairing code. Bluetooth/USB scanners and
  "Use this phone as a scanner" are untouched.
- If the plugin is not in the build (browser, or old APK), the button falls back to the old browser scanner.

Files
- www/index.html                         replace your project's www/index.html with this one
- native-scanner/NativeScannerPlugin.java the plugin
- native-scanner/apply_scanner.py        adds the plugin, dependencies and camera permission to android/

Steps
1. Copy www/index.html over your project's www/index.html.
2. Copy the native-scanner folder into the project root (next to www/ and android/).
3. From the project root run:   python3 native-scanner/apply_scanner.py
4. npx cap sync android, then build the APK as usual.

GitHub Actions: if your workflow creates android/ on every run (npx cap add android), add this step right
after that command and before the Gradle build:
      - run: python3 native-scanner/apply_scanner.py
If android/ is committed in your repo, run the script once on your PC and commit the changes instead.

Not tested
The plugin has not been compiled or run on a device (no Android SDK here). The patcher was tested on
simulated Capacitor projects only. Build, then test on a phone with a few real products before using it at checkout.
Needs Capacitor 3 or newer and compileSdk 34 or newer.

Building the APK without Android Studio
- .github/workflows/build-tindapos-apk.yml builds the APK on GitHub (apply scanner -> cap sync -> Gradle).
- Put the whole folder contents in your GitHub repo (keep the hidden .github folder), open Actions,
  run "Build TindaPOS APK (with camera scanner)", then download the artifact TindaPOS-debug-apk (app-debug.apk).
- If your repo already has its own workflow, just add the "Add native camera scanner" step to it instead.
