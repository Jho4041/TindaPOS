package com.tindapos.scanner;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.ViewGroup;
import android.view.Gravity;
import android.graphics.Color;
import android.widget.*;
import android.content.Context;
import android.content.Intent;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.camera.core.*;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.google.common.util.concurrent.ListenableFuture;
import com.google.mlkit.vision.barcode.BarcodeScanning;
import com.google.mlkit.vision.barcode.common.Barcode;
import com.google.mlkit.vision.common.InputImage;
import org.json.JSONObject;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.UUID;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

public class MainActivity extends AppCompatActivity {
    private static final int CAMERA_PERMISSION = 44;
    private PreviewView previewView;
    private EditText hostInput, codeInput, bluetoothMacInput;
    private Spinner connectionMode;
    private static final UUID SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private TextView status;
    private Button scanButton;
    private ExecutorService cameraExecutor;
    private final AtomicBoolean processing = new AtomicBoolean(false);
    private volatile String lastBarcode = "";
    private volatile long lastScanAt = 0;
    private boolean scanning = false;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        cameraExecutor = Executors.newSingleThreadExecutor();
        buildUi();
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, CAMERA_PERMISSION);
        }
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(18, 18, 18, 18);
        root.setBackgroundColor(Color.rgb(246,248,247));
        TextView title = new TextView(this);
        title.setText("TindaPOS Scanner");
        title.setTextColor(Color.rgb(20,55,37));
        title.setTextSize(26);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 8, 0, 16);
        title.setTypeface(null, 1);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        ImageView logo = new ImageView(this);
        logo.setImageResource(com.tindapos.scanner.R.drawable.tindapos_scanner_logo);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams logoParams = new LinearLayout.LayoutParams(112, 112);
        logoParams.gravity = Gravity.CENTER_HORIZONTAL;
        logoParams.setMargins(0, 0, 0, 10);
        root.addView(logo, logoParams);

        TextView hostLabel = new TextView(this); hostLabel.setText("Windows helper address (example: http://192.168.1.10:8765/scan)");
        root.addView(hostLabel);
        hostInput = new EditText(this); hostInput.setSingleLine(true); hostInput.setText("http://192.168.1.10:8765/scan"); hostInput.setHint("http://PC-IP:8765/scan");
        root.addView(hostInput, new LinearLayout.LayoutParams(-1, -2));

        TextView codeLabel = new TextView(this); codeLabel.setText("Pairing code shown on the Windows helper");
        root.addView(codeLabel);
        codeInput = new EditText(this); codeInput.setSingleLine(true); codeInput.setHint("8-character pairing code");
        root.addView(codeInput, new LinearLayout.LayoutParams(-1, -2));

        TextView modeLabel = new TextView(this); modeLabel.setText("Connection mode");
        root.addView(modeLabel);
        connectionMode = new Spinner(this);
        connectionMode.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item,
                new String[]{"Wi-Fi (Windows helper)", "Bluetooth Classic (paired SPP device)"}));
        root.addView(connectionMode, new LinearLayout.LayoutParams(-1, -2));

        TextView btLabel = new TextView(this); btLabel.setText("Bluetooth PC MAC address (Bluetooth mode only)");
        root.addView(btLabel);
        bluetoothMacInput = new EditText(this); bluetoothMacInput.setSingleLine(true); bluetoothMacInput.setHint("Example: AA:BB:CC:DD:EE:FF");
        root.addView(bluetoothMacInput, new LinearLayout.LayoutParams(-1, -2));

        previewView = new PreviewView(this);
        LinearLayout.LayoutParams camParams = new LinearLayout.LayoutParams(-1, 0, 1f);
        camParams.setMargins(0, 14, 0, 12);
        root.addView(previewView, camParams);

        scanButton = new Button(this); scanButton.setText("Start scanning");
        root.addView(scanButton, new LinearLayout.LayoutParams(-1, -2));
        scanButton.setOnClickListener(v -> {
            if (!scanning) {
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                    scanning = true; scanButton.setText("Stop scanning"); startCamera();
                } else ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, CAMERA_PERMISSION);
            } else {
                scanning = false; scanButton.setText("Start scanning");
                try { ProcessCameraProvider.getInstance(this).get().unbindAll(); } catch (Exception ignored) {}
            }
        });
        status = new TextView(this); status.setText("1. Run the Windows helper. 2. Enter its IP and pairing code. 3. Click the cashier SKU box, then scan.");
        status.setTextColor(Color.rgb(30,70,47)); status.setPadding(2, 10, 2, 4);
        root.addView(status, new LinearLayout.LayoutParams(-1, -2));
        setContentView(root);
    }

    private void startCamera() {
        ListenableFuture<ProcessCameraProvider> future = ProcessCameraProvider.getInstance(this);
        future.addListener(() -> {
            try {
                ProcessCameraProvider provider = future.get();
                Preview preview = new Preview.Builder().build();
                preview.setSurfaceProvider(previewView.getSurfaceProvider());
                ImageAnalysis analysis = new ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build();
                analysis.setAnalyzer(cameraExecutor, imageProxy -> {
                    if (!scanning || processing.get()) { imageProxy.close(); return; }
                    @SuppressWarnings("UnsafeOptInUsageError")
                    android.media.Image mediaImage = imageProxy.getImage();
                    if (mediaImage == null) { imageProxy.close(); return; }
                    InputImage input = InputImage.fromMediaImage(mediaImage, imageProxy.getImageInfo().getRotationDegrees());
                    processing.set(true);
                    BarcodeScanning.getClient().process(input)
                        .addOnSuccessListener(barcodes -> {
                            long now = System.currentTimeMillis();
                            for (Barcode barcode : barcodes) {
                                String value = barcode.getRawValue();
                                if (value != null && !value.trim().isEmpty() &&
                                    (!value.equals(lastBarcode) || now - lastScanAt > 1800)) {
                                    lastBarcode = value; lastScanAt = now;
                                    runOnUiThread(() -> sendBarcode(value));
                                    break;
                                }
                            }
                        })
                        .addOnCompleteListener(task -> { processing.set(false); imageProxy.close(); });
                });
                provider.unbindAll();
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis);
                status.setText("Camera ready. Aim at a product barcode.");
            } catch (Exception e) {
                status.setText("Camera error: " + e.getMessage());
            }
        }, ContextCompat.getMainExecutor(this));
    }

    private void sendBarcode(String barcode) {
        if (connectionMode != null && connectionMode.getSelectedItemPosition() == 1) {
            sendBluetoothBarcode(barcode);
            return;
        }
        String endpoint = hostInput.getText().toString().trim();
        if (!endpoint.endsWith("/scan")) endpoint = endpoint.replaceAll("/+$", "") + "/scan";
        String pairCode = codeInput.getText().toString().trim();
        final String finalEndpoint = endpoint;
        status.setText("Sending " + barcode + " over Wi-Fi …");
        Executors.newSingleThreadExecutor().execute(() -> {
            HttpURLConnection conn = null;
            try {
                JSONObject body = new JSONObject();
                body.put("barcode", barcode);
                body.put("pairCode", pairCode);
                conn = (HttpURLConnection) new URL(finalEndpoint).openConnection();
                conn.setRequestMethod("POST");
                conn.setConnectTimeout(4000);
                conn.setReadTimeout(4000);
                conn.setDoOutput(true);
                conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                byte[] bytes = body.toString().getBytes(StandardCharsets.UTF_8);
                conn.setFixedLengthStreamingMode(bytes.length);
                try (OutputStream os = conn.getOutputStream()) { os.write(bytes); }
                int response = conn.getResponseCode();
                runOnUiThread(() -> status.setText(response == 200 ? "Sent: " + barcode : "Connection rejected (HTTP " + response + "). Check PC IP and pairing code."));
            } catch (Exception e) {
                runOnUiThread(() -> status.setText("Could not reach Windows helper. Check same Wi-Fi, PC address, and firewall."));
            } finally { if (conn != null) conn.disconnect(); }
        });
    }

    private void sendBluetoothBarcode(String barcode) {
        String mac = bluetoothMacInput.getText().toString().trim();
        if (mac.isEmpty()) {
            status.setText("Enter the paired Windows Bluetooth device MAC address.");
            return;
        }
        BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
        if (adapter == null) {
            status.setText("This Android device does not support Bluetooth.");
            return;
        }
        if (!adapter.isEnabled()) {
            status.setText("Turn on Bluetooth and pair with the Windows PC first.");
            return;
        }
        status.setText("Connecting over Bluetooth …");
        Executors.newSingleThreadExecutor().execute(() -> {
            BluetoothSocket socket = null;
            try {
                BluetoothDevice device = adapter.getRemoteDevice(mac);
                socket = device.createRfcommSocketToServiceRecord(SPP_UUID);
                adapter.cancelDiscovery();
                socket.connect();
                socket.getOutputStream().write((barcode + "\\n").getBytes(StandardCharsets.UTF_8));
                socket.getOutputStream().flush();
                runOnUiThread(() -> status.setText("Sent over Bluetooth: " + barcode));
            } catch (Exception e) {
                runOnUiThread(() -> status.setText("Bluetooth connection failed. Pair the PC and phone, and configure the Windows helper's Bluetooth SPP receiver."));
            } finally {
                if (socket != null) try { socket.close(); } catch (Exception ignored) {}
            }
        });
    }

    @Override public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == CAMERA_PERMISSION && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            status.setText("Camera permission granted. Tap Start scanning.");
        } else status.setText("Camera permission is required to scan barcodes.");
    }

    @Override protected void onDestroy() {
        scanning = false;
        if (cameraExecutor != null) cameraExecutor.shutdown();
        super.onDestroy();
    }
}
