import json
import socket
import threading
import tkinter as tk
from tkinter import messagebox
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import ctypes
from ctypes import wintypes
import secrets
import ipaddress

PORT = 8765
# Optional: set environment variable TINDAPOS_BT_COM to a Windows incoming Bluetooth COM port (e.g. COM7).
BT_COM_PORT = __import__('os').environ.get('TINDAPOS_BT_COM', '').strip()
PAIR_CODE = secrets.token_hex(4).upper()

# Windows SendInput support: sends barcode text and Enter to the currently focused app.
user32 = ctypes.WinDLL("user32", use_last_error=True)
INPUT_KEYBOARD = 1
KEYEVENTF_KEYUP = 0x0002
KEYEVENTF_UNICODE = 0x0004
VK_RETURN = 0x0D

class KEYBDINPUT(ctypes.Structure):
    _fields_ = [("wVk", wintypes.WORD), ("wScan", wintypes.WORD),
                ("dwFlags", wintypes.DWORD), ("time", wintypes.DWORD),
                ("dwExtraInfo", ctypes.POINTER(ctypes.c_ulong))]
class INPUT_UNION(ctypes.Union):
    _fields_ = [("ki", KEYBDINPUT)]
class INPUT(ctypes.Structure):
    _fields_ = [("type", wintypes.DWORD), ("union", INPUT_UNION)]

def send_unicode_char(ch):
    code = ord(ch)
    extra = ctypes.c_ulong(0)
    down = INPUT(type=INPUT_KEYBOARD, union=INPUT_UNION(ki=KEYBDINPUT(0, code, KEYEVENTF_UNICODE, 0, ctypes.pointer(extra))))
    up = INPUT(type=INPUT_KEYBOARD, union=INPUT_UNION(ki=KEYBDINPUT(0, code, KEYEVENTF_UNICODE | KEYEVENTF_KEYUP, 0, ctypes.pointer(extra))))
    user32.SendInput(1, ctypes.byref(down), ctypes.sizeof(INPUT))
    user32.SendInput(1, ctypes.byref(up), ctypes.sizeof(INPUT))

def send_barcode(code):
    for ch in code:
        send_unicode_char(ch)
    extra = ctypes.c_ulong(0)
    down = INPUT(type=INPUT_KEYBOARD, union=INPUT_UNION(ki=KEYBDINPUT(VK_RETURN, 0, 0, 0, ctypes.pointer(extra))))
    up = INPUT(type=INPUT_KEYBOARD, union=INPUT_UNION(ki=KEYBDINPUT(VK_RETURN, 0, KEYEVENTF_KEYUP, 0, ctypes.pointer(extra))))
    user32.SendInput(1, ctypes.byref(down), ctypes.sizeof(INPUT))
    user32.SendInput(1, ctypes.byref(up), ctypes.sizeof(INPUT))

def local_ipv4():
    found = []
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ip = info[4][0]
            if not ip.startswith("127."):
                found.append(ip)
    except Exception:
        pass
    # Use route-selected interface if available.
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("192.0.2.1", 80))
        ip = s.getsockname()[0]
        s.close()
        if not ip.startswith("127."):
            found.insert(0, ip)
    except Exception:
        pass
    return list(dict.fromkeys(found))


def bluetooth_serial_worker(app, port_name):
    """Optional Bluetooth SPP receiver via a Windows incoming COM port. Requires pyserial."""
    try:
        import serial
        with serial.Serial(port_name, 9600, timeout=1) as ser:
            app.log(f"Bluetooth SPP listener active on {port_name}")
            while True:
                line = ser.readline().decode("utf-8", errors="ignore").strip()
                if line and len(line) <= 128 and all(ord(c) >= 32 for c in line):
                    app.root.after(0, lambda code=line: app.accept_scan(code))
    except Exception as exc:
        app.log(f"Bluetooth COM listener unavailable on {port_name}: {exc}")

class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        app.log(" ".join(str(x) for x in args))

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()

    def do_POST(self):
        if self.path != "/scan":
            self.send_error(404)
            return
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if length < 1 or length > 4096:
                self.send_error(413)
                return
            data = json.loads(self.rfile.read(length).decode("utf-8"))
            if not secrets.compare_digest(str(data.get("pairCode", "")), PAIR_CODE):
                self.send_error(401, "Invalid pairing code")
                return
            code = str(data.get("barcode", "")).strip()
            if not code or len(code) > 128 or any(ord(c) < 32 for c in code):
                self.send_error(400, "Invalid barcode")
                return
            # Schedule keystrokes on the GUI thread; user must focus the POS SKU field.
            app.root.after(0, lambda: app.accept_scan(code))
            body = b'{"ok":true}'
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        except Exception as e:
            self.send_error(400, "Bad request")

class HelperApp:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("TindaPOS Wireless Scanner Helper")
        self.root.geometry("560x430")
        self.root.resizable(False, False)
        tk.Label(self.root, text="TindaPOS Wireless Scanner", font=("Segoe UI", 16, "bold")).pack(pady=(14, 4))
        tk.Label(self.root, text="Keep this helper running on the cashier PC.", font=("Segoe UI", 10)).pack()
        tk.Label(self.root, text="PC address (enter this in the Android scanner):", font=("Segoe UI", 10, "bold")).pack(pady=(18, 4))
        self.ips = local_ipv4()
        self.ip_text = tk.StringVar(value="\n".join(f"http://{ip}:{PORT}" for ip in self.ips) or f"Find the PC's Wi-Fi IPv4 address, then use port {PORT}")
        tk.Label(self.root, textvariable=self.ip_text, font=("Consolas", 11), justify="center").pack()
        tk.Label(self.root, text="Pairing code:", font=("Segoe UI", 10, "bold")).pack(pady=(12, 2))
        tk.Label(self.root, text=PAIR_CODE, font=("Consolas", 18, "bold"), fg="#0a6b37").pack()
        tk.Label(self.root, text="Before scanning: open the cashier sale screen and click the SKU/barcode box.\nEach accepted scan types the barcode and presses Enter.", justify="center").pack(pady=12)
        self.status = tk.StringVar(value="Waiting for scanner connection…")
        tk.Label(self.root, textvariable=self.status, fg="#164a8a", wraplength=500).pack()
        self.log_box = tk.Text(self.root, height=5, width=66, state="disabled")
        self.log_box.pack(padx=12, pady=8)
        self.server = ThreadingHTTPServer(("0.0.0.0", PORT), Handler)
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        if BT_COM_PORT:
            threading.Thread(target=bluetooth_serial_worker, args=(self, BT_COM_PORT), daemon=True).start()
        self.root.protocol("WM_DELETE_WINDOW", self.close)

    def log(self, message):
        try:
            self.root.after(0, lambda: self._append_log(message))
        except Exception:
            pass

    def _append_log(self, message):
        self.log_box.configure(state="normal")
        self.log_box.insert("end", message + "\n")
        self.log_box.see("end")
        self.log_box.configure(state="disabled")

    def accept_scan(self, code):
        try:
            send_barcode(code)
            self.status.set(f"Sent barcode: {code} — make sure the POS SKU field is focused.")
            self.log_box.configure(state="normal")
            self.log_box.insert("end", f"Barcode sent: {code}\n")
            self.log_box.see("end")
            self.log_box.configure(state="disabled")
        except Exception as e:
            self.status.set("Could not send keyboard input. Run on Windows and try again.")

    def close(self):
        try:
            self.server.shutdown()
            self.server.server_close()
        finally:
            self.root.destroy()

if __name__ == "__main__":
    if __import__("os").name != "nt":
        print("This helper is intended for Windows 10/11.")
        raise SystemExit(1)
    app = HelperApp()
    app.root.mainloop()
