@echo off
cd /d "%~dp0"
py -3 tindapos_helper.py
if errorlevel 1 (
  echo.
  echo If Python is missing, install Python 3 from https://www.python.org/downloads/windows/
  echo During installation, check "Add Python to PATH".
  pause
)
