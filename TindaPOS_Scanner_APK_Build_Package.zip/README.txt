TindaPOS Scanner — branded starter implementation kit
======================================================

WHAT IS INCLUDED
- windows-helper/: Windows 10/11 Python helper that listens on port 8765 and types received barcode values plus Enter into the currently focused application.
- android-scanner/: Android Studio project source for a separate camera-based barcode scanner using CameraX + ML Kit. Includes TindaPOS Scanner logo and launcher icon, supports Android phones and tablets, and allows screen rotation.

IMPORTANT STATUS
This is source code, not a compiled/signed APK or Windows EXE. This environment does not have the Android SDK/Gradle installed, so the Android project has not been built or device-tested. Build the Android project in Android Studio before installing it. Review/test the Windows helper on a non-production machine first.

HOW TO TEST THE WINDOWS HELPER
1. Install Python 3 for Windows from https://www.python.org/downloads/windows/ (enable "Add Python to PATH").
2. Unzip this kit on the Windows cashier PC.
3. Run windows-helper\START_TINDAPOS_HELPER.bat.
4. Allow Python through Windows Defender Firewall for Private networks only, if prompted.
5. Note the PC's displayed IPv4 address and pairing code.
6. Open the TindaPOS cashier screen and click inside its barcode/SKU field.
7. Build/install the Android app, enter the PC address and pairing code, and tap Start scanning.
8. Scan one test product. Confirm only one item is added. Do not test on a live sale until verified.

ANDROID BUILD
1. Install Android Studio (current stable) and its Android SDK.
2. Open the android-scanner folder as an existing Android Studio project.
3. Let Gradle sync and install any requested SDK components.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. For a signed release APK, use Build > Generate Signed Bundle / APK.
6. Test on a spare Android phone before using it at checkout.

NETWORK / SAFETY NOTES
- The phone and cashier PC must be on the same trusted local Wi-Fi/LAN.
- The helper uses a temporary pairing code generated at each launch; do not share it outside your shop.
- The helper types into whichever Windows application currently has focus. Click the POS barcode/SKU field before scanning.
- It does not read your POS database or confirm whether the product exists; the POS application handles lookup after Enter.
- The helper uses plain HTTP on the local network. Use only on a trusted private LAN, not public Wi-Fi or internet port-forwarding.
- The helper is a starter prototype. Before production use, add a Windows firewall inbound rule limited to the local subnet, test focus behavior and duplicate handling, and verify the POS responds correctly to Enter.
- If the cashier SKU field does not accept keyboard input or needs a special hotkey, the integration needs adjustment.


ANDROID TABLET COMPATIBILITY
- The scanner app is not locked to portrait; it can rotate on phones and tablets.
- On an Android tablet used as a main POS, the scanner can be installed separately, but this scanner app does not itself replace the full TindaPOS cashier app.
- The current wireless helper targets the Windows cashier PC. Android-to-Android POS integration needs a reachable endpoint/API in the main POS app; it is not automatically provided by this Windows helper.
- Tablet compatibility and camera behavior still need to be compiled and tested on the actual tablet model.


DUAL CONNECTION MODE (WI-FI + BLUETOOTH)
- The Android scanner now offers a Settings-like connection mode selector: Wi-Fi or Bluetooth Classic (SPP).
- Wi-Fi mode uses the existing HTTP Windows helper and pairing code.
- Bluetooth mode sends barcode text over the standard Bluetooth Serial Port Profile UUID. It requires the Windows PC to be paired and expose an incoming Bluetooth serial COM port that accepts SPP connections.
- For Windows Bluetooth mode, configure Windows Bluetooth incoming COM port first. Then install pyserial with: py -3 -m pip install pyserial
- Start the helper with the COM port configured, for example from Command Prompt:
    set TINDAPOS_BT_COM=COM7
    py -3 tindapos_helper.py
  Replace COM7 with the actual incoming Bluetooth COM port in Windows Device Manager. The helper listens for newline-terminated barcode strings and types them into the currently focused POS field.
- Bluetooth mode has not been tested on actual Windows/Android hardware. Some Windows Bluetooth stacks do not expose an incoming SPP COM port by default; if your PC does not offer one, Bluetooth requires a different Windows Bluetooth server implementation. Use Wi-Fi mode until Bluetooth SPP is verified.
- On Android, pair the phone/tablet with the PC in system Bluetooth settings first. Enter the PC Bluetooth MAC address in the scanner app and select Bluetooth mode.
- Do not expose the Wi-Fi helper to the public internet. Use only trusted local networks.


BUILD APK USING GITHUB ACTIONS (NO LOCAL ANDROID SDK REQUIRED)
1. Create a private repository on GitHub and upload the contents of this kit, including the hidden .github folder.
2. Open the repository's Actions tab.
3. Select "Build TindaPOS Scanner APK" and choose "Run workflow" (or push a commit to start it).
4. Wait for the workflow to finish successfully.
5. Open the completed workflow run and download the artifact named "TindaPOS-Scanner-debug-apk".
6. Extract the artifact ZIP to get app-debug.apk, then install it on a test Android device.

This creates a DEBUG APK for testing, not a Play Store release or a signed production release. The source has not been compiled or device-tested in this chat. Build success and runtime behavior must be verified by the workflow and a physical-device test. Bluetooth SPP and Android tablet-to-tablet receiving are especially dependent on the device and receiver configuration.
